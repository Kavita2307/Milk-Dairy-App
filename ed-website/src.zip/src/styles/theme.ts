export const theme = {
  sidebarBg: "#0B2C4A",
  accent: "#F7941D",
  pageBg: "#FFFFFF",
  textDark: "#1F2937",
};
