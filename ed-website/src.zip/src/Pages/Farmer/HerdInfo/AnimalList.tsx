import { useContext, useEffect, useState } from "react";
import { useParams, useNavigate, useLocation } from "react-router-dom";
import { apiFetch } from "../../../app/fetcher";
import "../../../styles/animalList.css";
import { AuthContext } from "../../../features/auth/authContext";

export default function AnimalList() {
  const { groupId } = useParams();
  const navigate = useNavigate();
  const location = useLocation();
  const user = useContext(AuthContext);
  const userId = user?.id;

  // passed from group card navigation
  const { groupTitle } = (location.state || {}) as {
    groupTitle?: string;
  };

  const [animals, setAnimals] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadAnimals();
  }, [groupId]);

  const loadAnimals = async () => {
    try {
      const res = await apiFetch("/api/animals");
      console.log("ANIMALS API RESPONSE:", res);
      const animalsArray = Array.isArray(res)
        ? res
        : Array.isArray(res?.data)
        ? res.data
        : [];

      // ✅ FILTER BY groupId AND userId
      setAnimals(
        animalsArray.filter(
          (a: any) =>
            Number(a.groupId) === Number(groupId) &&
            Number(a.userId) === Number(userId)
        )
      );
    } catch (err) {
      console.error("LOAD ANIMALS ERROR:", err);
      alert("Failed to load animals");
    } finally {
      setLoading(false);
    }
  };

  const isMilking = Number(groupId) < 4;

  return (
    <div className="animal-list-page">
      {/* HEADER */}
      <div className="page-header">
        <h2>{groupTitle || `Group ${groupId}`} – Animals</h2>

        {/* ADD NEW ANIMAL */}
        <button
          className="add-btn"
          onClick={() => {
            if (isMilking) {
              navigate(`/farmer/milking/${groupId}/add`);
            } else {
              navigate(`/farmer/non-milking/${groupId}/add`);
            }
          }}
        >
          ➕ Add New Animal
        </button>
      </div>

      {/* EMPTY STATE */}
      {!loading && animals.length === 0 && (
        <div className="empty-box">
          <div className="empty-icon">🐄</div>
          <h3>No animals added</h3>
          <p>Click “Add New Animal” to get started</p>
        </div>
      )}

      {/* ANIMAL LIST */}
      {!loading && animals.length > 0 && (
        <div className="animal-cards">
          {animals.map((item) => (
            <div
              key={item.id}
              className="animal-card"
              onClick={() => {
                if (isMilking) {
                  navigate(
                    `/farmer/milking/${groupId}/edit/${item.animalNumber}`
                  );
                } else {
                  navigate(
                    `/farmer/non-milking/${groupId}/edit/${item.animalNumber}`
                  );
                }
              }}
            >
              <div className="animal-icon">🐄</div>

              <div className="animal-text">Animal #{item.animalNumber}</div>

              <div className="arrow">›</div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
