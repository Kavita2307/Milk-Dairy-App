export default function OfficialDashboard() {
  return (
    <>
      <h2>All Farmers</h2>
      <p>Official can view all farmers and access full data.</p>
    </>
  );
}
